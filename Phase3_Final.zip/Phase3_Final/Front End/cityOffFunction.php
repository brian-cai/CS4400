<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>City Official - Choose Function</title>  
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="form">
      <h1>CHOOSE FUNCTIONALITY </h1>


      <a href= "cityOffView.php"> Filter/Search POI</a>
      
      <br><br>

      <a href= "cityOffPOIReport.php"> POI REPORT</a>

      <br><br>
      
      
      <button>
        <a href="index.php">        
          Logout
        </a>
      </button>
    </form>

  </div>

<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

<script src="js/index.js"></script>
</body>
