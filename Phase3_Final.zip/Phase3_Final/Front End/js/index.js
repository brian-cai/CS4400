$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});


//$('b').click( function() {alert("link to pending data points"); } );

$('c').click( function() {alert("link to pending city official accounts"); } );

$('d').click( function() {} );

$('submitted').click( function() {alert("placeholder for submit!");})


